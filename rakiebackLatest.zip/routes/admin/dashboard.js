const express = require('express');
const router = express.Router();
const auth = require('../../middleware/authmiddleware');
const controller = require('../../controllers/admin/dashboardcontroller');

router.use(auth);
router.get('/', controller.getDashboard);

module.exports = router;
